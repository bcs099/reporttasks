data=[5,10,15,20,25];
m=mean(data);
v=var(data);
disp('Mean of data= ')
disp(m)
disp('Variance of data= ')
disp(v)