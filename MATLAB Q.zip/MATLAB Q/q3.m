data=[2,3,3,4,5,5,5,6,7,8,8,9];
histogram(data)
xlabel('Values')
ylabel('Frequency')
title('histogram of sample data')