function [p, c] = permcomb(n, r)
    % Permutation: nPr = n! / (n-r)!
    p = factorial(n) / factorial(n-r);

    % Combination: nCr = n! / (r! * (n-r)!)
    c = factorial(n) / (factorial(r) * factorial(n-r));
end