x=(1:5);
y=[10,20,30,40,50];
t=(table(x,y));
writetable(t,'data.csv');
data=readtable('data.csv');
disp(data)
