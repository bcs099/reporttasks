P_spam=0.4;
P_notspam=0.6;
P_word_given_spam=0.7;
P_word_given_notspam=0.2;
P_word=P_word_given_spam *  P_spam + P_word_given_notspam * P_notspam;
P_spam_given_word=(P_word_given_spam *  P_spam)/P_word;
disp(P_spam_given_word)
